Clutch Studio - sandbox test file

This ZIP exists only to test checkout and instant delivery in PayPal sandbox.
It contains a plain 30 x 30 x 3 mm plate (test-token.stl). It is not a car part.

License: CC0 1.0 (public domain dedication). Made by Clutch Studio for testing.
